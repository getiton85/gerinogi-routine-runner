Install guide

1. Extract this ZIP file.
2. Run install.bat.
3. After installation, use the desktop shortcut named "상태루틴 실행".

Install folder:
C:\gerinogi

Updates are applied to the installed folder.
Existing logs, slot points, and captured images are preserved.
