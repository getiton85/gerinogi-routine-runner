$ErrorActionPreference = 'Stop'

$sourceRoot = Join-Path $PSScriptRoot 'release'
$installRoot = 'C:\gerinogi'
$desktop = [Environment]::GetFolderPath('DesktopDirectory')
$startMenu = Join-Path ([Environment]::GetFolderPath('StartMenu')) 'Programs\GerinogiRoutineRunner'

$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    $args = '-NoProfile -ExecutionPolicy Bypass -File "' + $PSCommandPath + '"'
    Start-Process -FilePath powershell.exe -ArgumentList $args -Verb RunAs
    exit
}

if (-not (Test-Path -LiteralPath $sourceRoot)) {
    throw "The release folder was not found: $sourceRoot"
}

New-Item -ItemType Directory -Force -Path $installRoot | Out-Null
New-Item -ItemType Directory -Force -Path $startMenu | Out-Null

$coreFiles = @(
    'local_state_routine_runner.ps1',
    'update_manifest_url.txt',
    '상태루틴 실행.bat',
    '상태루틴 실행.vbs',
    '상태루틴 관리자 실행.bat',
    '상태루틴 관리자 실행.vbs',
    '상태루틴 디버그 실행.bat',
    'gerinogi.ico'
)

foreach ($file in $coreFiles) {
    $src = Join-Path $sourceRoot $file
    if (Test-Path -LiteralPath $src) {
        Copy-Item -LiteralPath $src -Destination (Join-Path $installRoot $file) -Force
    }
}

$sampleSource = Join-Path $sourceRoot 'state_samples'
$sampleTarget = Join-Path $installRoot 'state_samples'
if (Test-Path -LiteralPath $sampleSource) {
    Get-ChildItem -LiteralPath $sampleSource -Recurse -File | ForEach-Object {
        $relative = $_.FullName.Substring($sampleSource.Length).TrimStart('\')
        $target = Join-Path $sampleTarget $relative
        New-Item -ItemType Directory -Force -Path (Split-Path -Parent $target) | Out-Null
        if (-not (Test-Path -LiteralPath $target)) {
            Copy-Item -LiteralPath $_.FullName -Destination $target -Force
        }
    }
}

$wsh = New-Object -ComObject WScript.Shell
$iconPath = Join-Path $installRoot 'gerinogi.ico'

function New-AppShortcut {
    param(
        [string]$Path,
        [string]$Target
    )
    $shortcut = $wsh.CreateShortcut($Path)
    $shortcut.TargetPath = $Target
    $shortcut.WorkingDirectory = $installRoot
    if (Test-Path -LiteralPath $iconPath) {
        $shortcut.IconLocation = $iconPath
    } else {
        $shortcut.IconLocation = "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe,0"
    }
    $shortcut.Save()
}

$normalLauncher = Join-Path $installRoot '상태루틴 실행.vbs'
$adminLauncher = Join-Path $installRoot '상태루틴 관리자 실행.vbs'

if (Test-Path -LiteralPath $normalLauncher) {
    New-AppShortcut -Path (Join-Path $desktop '상태루틴 실행.lnk') -Target $normalLauncher
    New-AppShortcut -Path (Join-Path $startMenu '상태루틴 실행.lnk') -Target $normalLauncher
}

if (Test-Path -LiteralPath $adminLauncher) {
    New-AppShortcut -Path (Join-Path $desktop '상태루틴 관리자 실행.lnk') -Target $adminLauncher
    New-AppShortcut -Path (Join-Path $startMenu '상태루틴 관리자 실행.lnk') -Target $adminLauncher
}

$installInfo = @"
installed_at=$((Get-Date).ToString('s'))
install_root=$installRoot
version=1.0.2
"@
[System.IO.File]::WriteAllText((Join-Path $installRoot 'install_info.txt'), $installInfo, [System.Text.Encoding]::UTF8)

try {
    icacls $installRoot /grant "$env:USERNAME:(OI)(CI)F" | Out-Null
} catch {
    Write-Host 'Permission adjustment was skipped.'
}

Write-Host ''
Write-Host 'Installation completed.'
Write-Host "Install folder: $installRoot"
Write-Host 'Desktop shortcuts were created.'
Write-Host ''
Write-Host 'Press any key to close this window.'
[void][System.Console]::ReadKey($true)
